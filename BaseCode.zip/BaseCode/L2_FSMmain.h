void L2_initFSM(uint8_t myId, uint8_t destId);
void L2_configDestId(uint8_t destId);
void L2_FSMrun(void);